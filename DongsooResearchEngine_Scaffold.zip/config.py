# Global configuration
