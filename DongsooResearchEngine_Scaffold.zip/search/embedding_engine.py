# Embedding engine
