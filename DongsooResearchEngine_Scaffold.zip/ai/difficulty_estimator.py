# Difficulty estimator
