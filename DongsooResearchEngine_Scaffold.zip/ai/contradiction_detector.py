# Contradiction detector
